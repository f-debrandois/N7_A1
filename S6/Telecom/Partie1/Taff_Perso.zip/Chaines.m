% Projet de Telecommunication : Etude de modulateurs bande de base
% Nom / Prénom : Foucher de Brandois Félix
% Nom / Prénom : Alioui Ilyasse
% Groupe : 1SN-E

clear all ; close all;

% Constantes
n_bits = 2000; % Nombre de bits
bits = randi([0 1], n_bits, 1); % Bits à transmettre

Fe = 24000; % Fréquence d'échantillonnage
Te = 1/Fe; % Période d'échantillonnage
Rb = 3000; % Débits de la transmission
Tb = 1/Rb; % Période par bits


%% 4. Etude de l'impact du bruit et du filtrage adapté, notion d'efficacité en puissance
% BRUIT
bruit = 0;


% Chaine 1
Ts = Tb; % Période symbole
Ns = Fe * Ts; % Nombre d'échantillons par bits
T1 = 0:Te:(n_bits*Ns-1)*Te; % Echelle temporelle
    % Mapping
    An = (2*bits - 1)';
    At = kron(An, [1, zeros(1, Ns-1)]);

    % Filtre de mise en forme
    h1 = ones(1, Ns1); % Reponse impulsionnelle du filtre
    x1 = filter(h1, 1, At) + bruit;

    % Canal de propagation
    hc1 = 0;
    r1 = filter(hc1, 1, x1);

    % Filtre de réception
    hr1 = ones(1, Ns); % Reponse impulsionnelle du filtre de réception
    z1 = filter(hr1, 1, r1);

    % Echantillonage
    n0 = Ns;
    echantillon = z1(n0:Ns:end);

    % Detecteur de seuil
    bits_sortie1 = (sign(echantillon) + 1) / 2;
    TEB1 = sum(bits_sortie1' ~= bits) / n_bits;
 
% Chaine 2
Ts = Tb; % Période symbole
Ns = Fe * Ts; % Nombre d'échantillons par bits
T2 = 0:Te:(n_bits*Ns-1)*Te; % Echelle temporelle
    % Mapping
    An = (2*bits - 1)';
    At = kron(An, [1, zeros(1, Ns-1)]);

    % Filtre de mise en forme
    h2 = ones(1, Ns); % Reponse impulsionnelle du filtre
    x2 = filter(h2, 1, At) + bruit;

    % Canal de propagation
    hc2 = 0;
    r2 = filter(hc2, 1, x12);

    % Filtre de réception
    hr2 = ones(1, Ns); % Reponse impulsionnelle du filtre de réception
    z2 = filter(hr2, 1, r2);

    % Echantillonage
    n0 = Ns;
    echantillon = z2(n0:Ns:end);

    % Detecteur de seuil
    bits_sortie2 = (sign(echantillon) + 1) / 2;
    TEB2 = sum(bits_sortie2' ~= bits) / n_bits;

% Chaine 3
Ts = Tb; % Période symbole
Ns = Fe * Ts; % Nombre d'échantillons par bits
T3 = 0:Te:(n_bits*Ns-1)*Te; % Echelle temporelle
    % Mapping
    An = (2*bits - 1)';
    At = kron(An, [1, zeros(1, Ns-1)]);

    % Filtre de mise en forme
    h3 = ones(1, Ns); % Reponse impulsionnelle du filtre
    x3 = filter(h3, 1, At) + bruit;

    % Canal de propagation
    hc3 = 0;
    r3 = filter(hc3, 1, x3);

    % Filtre de réception
    hr3 = ones(1, Ns); % Reponse impulsionnelle du filtre de réception
    z3 = filter(hr3, 1, r3);

    % Echantillonage
    n0 = Ns;
    echantillon = z3(n0:Ns:end);

    % Detecteur de seuil
    bits_sortie3 = (sign(echantillon) + 1) / 2;
    TEB3 = sum(bits_sortie3' ~= bits) / n_bits;

% 4.1 Etude de chaque chaine de trasmission
% 1. Sans bruit
% Chaine 1
figure('name', 'Chaine 1')

    % Diagramme de l'oeil
    nexttile
    plot(reshape(z1,Ns,length(z1)/Ns));
    title('Diagramme de l''oeil');
    xlabel('Temps (s)')

    fprintf("TEB chaine 1 : " + TEB1 + "\n");

% Chaine 2
figure('name', 'Chaine 2')

    % Diagramme de l'oeil
    nexttile
    plot(reshape(z1,Ns,length(z1)/Ns));
    title('Diagramme de l''oeil');
    xlabel('Temps (s)')

    fprintf("TEB chaine 1 : " + TEB1 + "\n");


% 2. Avec bruit



% 4.2 Comparaison des chaines de transmission implantées


