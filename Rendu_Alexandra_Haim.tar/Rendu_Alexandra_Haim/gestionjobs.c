#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include "readcmd.h"
#include <signal.h>
#include <stdbool.h>
#include "gestionjobs.h"

struct listeJobs liste[1000];
int Capacite = 0;
bool supprimer = true;

/* Commande "lj" : affiche la liste des jobs */
void listerjobs() {
    int l = 0;
    while (l < Capacite) {
        printf("Processus %d de pid %d est %s avec la commande ", liste[l].id, liste[l].pid, liste[l].etat);
        int k = 0;
        int p = 0;
        while (liste[l].commande[k]!= NULL){    // Affichage de la ligne de commande
            while (liste[l].commande[k][p] != NULL) {
                printf("%s", liste[l].commande[k][p]);
                printf(" ");
                p++;
            }
        k++;
        }
        printf("\n");
        l++;
    }
}

/* Commande "sj" : stopper le job */
void stopjobs(struct cmdline* s, bool sortieSJ) {
    pid_t pidStop = getPid(atoi(s->seq[0][1]));
    if (pidStop == -1) {
        printf("Processus %d n'existe pas\n", atoi(s->seq[0][1]));
    }
    else {
        kill(pidStop, SIGSTOP);
        sortieSJ = true;
    }
}

/* Commande "bg" : reprendre un processus en arrière plan */
void background(struct cmdline* s){
    pid_t pidbg = getPid(atoi(s->seq[0][1]));
    if (pidbg == -1) {
        printf("Processus %d n'existe pas\n", atoi(s->seq[0][1]));
    } else {
        kill(pidbg, SIGCONT);
    }
}

/* Commande "fg" : reprendre un processus au premier plan */
void foreground(struct cmdline* s, int codeTerm) {
    pid_t pidfg = getPid(atoi(s->seq[0][1]));
    if (pidfg == -1) {
        printf("Processus %d n'existe pas\n", atoi(s->seq[0][1]));
    } else {
        kill(pidfg, SIGCONT);
        usleep(10);
        waitpid(pidfg,&codeTerm, 0);
        if (supprimer) {
            suppProc(pidfg);
        }
        supprimer = true;
    }
}

/* Supprimer le processus de pid pidSuppr de liste, un tableau */
void suppProc(pid_t pidSuppr) {
    int i = 0;
    while (i < Capacite && liste[i].pid != pidSuppr) {
        i++;
    }
    if (liste[i].pid == pidSuppr) {
        while (i < Capacite - 1) {
            liste[i] = liste[i+1];
            i++;
        }
    Capacite--;
    }
}

/* Modifier l'état du processus de pid pidModif de liste, un tableau */
void modifEtat(pid_t pidModif, char* etat) {
    int i = 0;
    while (i < Capacite && liste[i].pid != pidModif) {
        i++;
    }
    if (liste[i].pid == pidModif) {
        liste[i].etat = etat;
    }
}

/* Obtenir le pid d'un processus à partir de son numéro interne au shell */
pid_t getPid(int num) {
    int i = 0;
    while (i < Capacite && liste[i].id != num) {
        i++;
    }
    if (liste[i].id == num) {
        return liste[i].pid;
    } else {
        return -1;
    }
}