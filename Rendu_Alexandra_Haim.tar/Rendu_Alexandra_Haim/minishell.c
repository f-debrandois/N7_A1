#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include "readcmd.h"
#include <signal.h>
#include <stdbool.h>
#include "gestionjobs.h"
#include <fcntl.h>

/** Copier la ligne de commande */
char*** copierLigne(char***  commande) {
    int i = 0;
    char*** copie = malloc(sizeof(char **));
    while (commande[i] != NULL) {
        copie = realloc(copie, sizeof(char *)*(i+1));
        copie[i] = malloc(sizeof(char *)); 
        int j = 0;
        while (commande[i][j] != NULL) {
            copie[i] = realloc(copie[i], sizeof(char *)*(j+1));
            copie[i][j] = malloc(sizeof(char*)*(strlen(commande[i][j])+1));
            strcpy(copie[i][j],commande[i][j]);
            j++;
        }
    copie[i] = realloc(copie[i], sizeof(char*)*(j+1));
    copie[i][j] = NULL; 
    i++;
    }
    copie = realloc(copie, sizeof(char**)*(i+1));
    copie[i] = NULL;
    return copie;
}

/** Redirection de la sortie */
static void redirOut(char * out) {
    if (out != NULL) {
        int fdout = open(out, O_CREAT | O_TRUNC | O_WRONLY, S_IRGRP | S_IROTH | S_IRUSR | S_IWUSR);
        if (fdout < 0) {
            printf("Porblème lors de l'ouverture");
            exit(EXIT_FAILURE);
        }
        if (dup2(fdout, 1) < 0) {
            perror("Problème lors du dup2");
        }
    }
}

/** Redirection de l'entrée */
static void redirIn(char * in) {
    if (in != NULL) {
        int fdin = open(in, O_RDONLY);
        if (fdin < 0) {
            printf("Porblème lors de l'ouverture");
            exit(EXIT_FAILURE);
        }
        if (dup2(fdin, 0) < 0) {
            perror("Problème lors du dup2");
        }
    }
}

/** Handler permettant de traiter l'arrivée d'un signal */
void handler(int signal_num) {
    int fils_termine, wstatus;
    while ((fils_termine = (int) waitpid(-1, &wstatus, WNOHANG | WUNTRACED | WCONTINUED)) > 0) {
        
        if WIFEXITED(wstatus) {
            suppProc(fils_termine);
        }
        else if (WIFCONTINUED(wstatus)) {
            modifEtat(fils_termine, "actif");
        }
        else if (WIFSTOPPED(wstatus)) {
            printf("ctrlZ\n");
            supprimer = false;
            modifEtat(fils_termine, "suspendu");
        } else if (WIFSIGNALED(wstatus)) {
            printf("ctrlC\n");
            suppProc(fils_termine);
        }
    }
}

int main(int argc, char *argv[])
{
    // Initialisation des variables
    int id = 0;
    struct cmdline* s;
    pid_t pidFils;
    int codeTerm = 0;
    bool sortieSJ = false;  // Booléen utilisé pour l'affichage

    // Handler
    struct sigaction action;
    action.sa_handler = handler;
    action.sa_flags = 0;
    sigemptyset(&action.sa_mask);
    sigaction(SIGCHLD, &action, NULL);
    sigaction(SIGINT, &action, NULL);
    sigaction(SIGTSTP, &action, NULL);

    while (1) {
        sigset_t sigset;
        sigemptyset(&sigset);
        sigaddset(&sigset, SIGINT);
        sigaddset(&sigset, SIGTSTP);
        sigprocmask(SIG_BLOCK, &sigset, NULL);
        
        /* Gérer l'affichage */
        printf(">>> ");

        /* Lecture de la commande */
        s = readcmd();
        
        /* CTRL+D */
        if (feof(stdin)){ 
            break;
        /* Commande nulle */
        } else if (s == NULL) {
            if (sortieSJ) {
                printf("Processus stopped \n");
                sortieSJ = false;
            }
        continue;
        /* Eviter une erreur dans la commande */
        } else if (s->err == NULL){ 
            if (s->seq[0]==NULL){
                continue;
            /* Gérer les commandes internes au minishell */
            } else if (strcmp(s->seq[0][0], "exit") == 0) {
                break;
            } else if (strcmp(s->seq[0][0], "cd") == 0) {
                if (s->seq[0][1] == NULL || strcmp(s->seq[0][1], "~") == 0) {
                    chdir(getenv("HOME"));
                } else if (chdir(s->seq[0][1]) == -1) {
                    printf("Répertoire invalide\n");
                } else {
                    chdir(s->seq[0][1]);
                }
            
            /* Gérer les commandes concernant la liste des jobs */
            } else if (strcmp(s->seq[0][0], "lj") == 0) {
                listerjobs();
            } else if (strcmp(s->seq[0][0], "sj") == 0) {
                stopjobs(s, sortieSJ);
            } else if (strcmp(s->seq[0][0], "bg") == 0) {
                background(s);
            } else if (strcmp(s->seq[0][0], "fg") == 0) {
                sigprocmask(SIG_UNBLOCK, &sigset, NULL);
                foreground(s, codeTerm);
            } else if (strcmp(s->seq[0][0], "susp") == 0) {
                break;
            } else {
                int i = 0;
                int premier_proc = 1;
                int p2[2];
                int p1[2];

                /* Création du premier pipe */
                if (pipe(p1) < 0) {
                    perror("Erreur de pipe");
                    exit(EXIT_FAILURE);
                }
                while (s->seq[i] != NULL) {
                    /* Création du second pipe */
                    if (pipe(p2) < 0) {
                        perror("Erreur de pipe");
                        exit(EXIT_FAILURE);
                    }
                    /* Trouver le dernier processus */
                    int dernier_proc = s->seq[i+1] == NULL;

                    /* Créer le processus fils */
                    pidFils = fork();

                    /* S'il y a une erreur lors de la création du processus fils */
                    if (pidFils == -1) {    
                        printf("Erreur fork\n");
                        exit(1);

                    /* fils */
                    } else if (pidFils == 0) {
                        /* Pas de pipe */
                        if (premier_proc != 0 && dernier_proc != 0) {
                            /* Redirections */
                            redirOut(s->out);
                            redirIn(s->in);
                            close(p2[0]);
                            close(p2[1]);
                            close(p1[0]);
                            close(p1[1]);
                        } else {
                            /* Cas du premier processus */
                            if (premier_proc) { 
                                redirIn(s->in);
                                dup2(p2[1], 1);
                                close(p1[0]);
                                close(p1[1]);
                                close(p2[1]);
                            /* cas du dernier processus */
                            } else if (dernier_proc) { 
                                redirOut(s->out);
                                dup2(p1[0], 0);
                                close(p1[0]);
                                close(p2[0]);
                                close(p2[1]);
                            /* cas d'un processus au milieu */
                            } else {
                                dup2(p1[0], 0);
                                dup2(p2[1], 1);
                                close(p1[0]);
                                close(p1[1]);
                                close(p2[0]);
                                close(p2[1]);
                            }
                        }
                        if (s->backgrounded == NULL) {
                            /* Démasquer les signaux si processus en avant-plan */
                            sigprocmask(SIG_UNBLOCK, &sigset, NULL);
                        }
                        /* Exécuter la commande */
                        execvp(s->seq[i][0], s->seq[i]);    
                        exit(1);

                    /* père */    
                    } else { 
                        close(p1[0]);
                        close(p1[1]);
                        close(p2[1]);
                        p1[0] = p2[0];
                        p1[1] = p2[1];
                        if (premier_proc) {
                            premier_proc = 0;
                        }
                        i++;
                        /* Ajouter le processus à la liste des processus */
                        liste[Capacite].pid = pidFils;
                        liste[Capacite].id = id++;
                        liste[Capacite].commande = copierLigne(s->seq);
                        liste[Capacite].etat = "actif";
                        Capacite++;
                        /* Si le processus est en avant-plan, on attend */
                        if (s->backgrounded == NULL) {
                            pause();
                        }
                    }
                }
            }
        } else {
            printf("%s\n", s->err);
        }
    }
    printf("Salut\n");
    exit(0);
    return EXIT_SUCCESS;
}
