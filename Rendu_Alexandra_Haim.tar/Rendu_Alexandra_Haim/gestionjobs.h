#ifndef __GESTIONJOBS_H
#define __GESTIONJOBS_H

/* Gère la liste de jobs :
 * lj : lister des jobs
 * sj : stopper les jobs
 * fg : reprendre un processus au premier plan
 * bg : reprendre un processus en arrière plan
 */

/** Construction de la liste (tableau) utilisée pour stocker toutes les informations demandées */
struct listeJobs {
  pid_t pid;
  int id;
  char*** commande;
  char* etat;
};
extern struct listeJobs liste[];
extern int Capacite; // Capacité du tableau qui évolue dans le temps
extern bool supprimer;

void listerjobs();
    /* Commande "lj" : affiche la liste des jobs */

void stopjobs(struct cmdline* s, bool sortieSJ);
    /* Commande "sj" : stopper le job */

void background(struct cmdline* s);
    /* Commande "bg" : reprendre un processus en arrière plan */

void foreground(struct cmdline* s, int codeTerm);
    /* Commande "fg" : reprendre un processus au premier plan */

void suppProc(pid_t pidSuppr); 
    /* Supprimer le processus de pid pidSuppr de liste, un tableau */

void modifEtat(pid_t pidModif, char* etat); 
    /* Modifier l'état du processus de pid pidModif de liste, un tableau */

pid_t getPid(int num);
    /* Obtenir le pid d'un processus à partir de son numéro interne au shell */

#endif