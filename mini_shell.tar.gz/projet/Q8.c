#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>
#include "readcmd.c"

#define TAILLE_MAX 30
#define NB_MAX 128

struct processus {

  int pid;
  char* situation;
  char commande[TAILLE_MAX];

};

struct processus processus[NB_MAX];
int nb_proc = 0;


void insertion (int pid, char *** seq, char * fond) {
	processus[nb_proc].pid = pid;
	processus[nb_proc].situation = "ACTIF";

	int i = 0;
	while(seq[i] != NULL) {
		int j = 0;
		while(seq[i][j] != NULL) {
			if ((i == 0) & (j == 0)) {
				strcpy(processus[nb_proc].commande, seq[i][j]);
			} else {
				strcat(processus[nb_proc].commande, " ");
				strcat(processus[nb_proc].commande, seq[i][j]);
			}
			j++;
		}
		i++;
	}

	if (fond != NULL) {
		strcat(processus[nb_proc].commande, " &");
	}

	nb_proc++;
}


int trouver_tab (int pid) {
  int x;

  for(int i = 0; i< nb_proc; i++) {
  	if (processus[i].pid == pid) {
  		x = i;
  		i = NB_MAX;
  	}
  }

  return x;
}


void retirer_tab (int pid) {
  int x;

  for(int i = 0; i < nb_proc; i++) {
  	if (processus[i].pid == pid) {
  		x = i;
		if(x != (nb_proc-- - 1)) {
			processus[x] = processus[nb_proc];
		}
  		i = NB_MAX;
  	}
  }
}
 

void suivi_fils (int sig) {

    int etat_fils, pid_fils;

    do {

        pid_fils = (int) waitpid(-1, &etat_fils, WNOHANG | WUNTRACED | WCONTINUED);

        if ((pid_fils == -1) && (errno != ECHILD)) {

            perror("waitpid");

            exit(EXIT_FAILURE);

        } else if (pid_fils > 0) {

            if (WIFSTOPPED(etat_fils)) {

		processus[trouver_tab(pid_fils)].situation = "SUSPENDU";

            } else if (WIFCONTINUED(etat_fils)) {

		processus[trouver_tab(pid_fils)].situation = "ACTIF";

            } else if (WIFEXITED(etat_fils)) {

		retirer_tab (pid_fils);

            } else if (WIFSIGNALED(etat_fils)) {

		retirer_tab (pid_fils);

            }

        }

    } while (pid_fils > 0);

    /* autres actions après le suivi des changements d'état */

}


int courant = 0;


void ctrl_c (int sig) {
  kill(courant, SIGKILL);
  printf("\n");
}


void ctrl_z (int sig) {
  kill(courant, SIGSTOP);
  printf("\n");
}



/* Lire une commande et l'executer */
int main() {

  sigset_t ens_sig;

  sigemptyset(&ens_sig);
  sigaddset(&ens_sig, SIGINT);
  sigaddset(&ens_sig, SIGTSTP);

  signal(SIGCHLD, suivi_fils);
  signal(SIGINT, ctrl_c);
  signal(SIGTSTP, ctrl_z);

  struct cmdline* ligne;

  int wstatus, descout, descin;

  do {

	sigprocmask(SIG_BLOCK, &ens_sig, NULL);
	//printf("%s ", getcwd(NULL, 0));
	printf(" ");

	ligne = readcmd();
	if(ligne->err != NULL){
		printf("Erreur lors de la lecture de la commande\n");
		exit(-1);
	}

	if (strcmp(ligne->seq[0][0], "cd") == 0) {

		chdir(ligne->seq[0][1]);
		printf("%s \n", getcwd(NULL, 0));

	} else if (strcmp(ligne->seq[0][0], "exit") == 0) {

		exit(EXIT_SUCCESS);

	} else if (strcmp(ligne->seq[0][0], "jobs") == 0) {

		for(int i = 0; i < nb_proc; i++) {
			printf("[%d]    %d    %s    ", i+1, processus[i].pid, processus[i].situation);
			printf("%s \n", processus[i].commande);
		}

	} else if (strcmp(ligne->seq[0][0], "stop") == 0) {

		kill(atoi(ligne->seq[0][1]), SIGSTOP);

	} else if (strcmp(ligne->seq[0][0], "bg") == 0) {

		kill(atoi(ligne->seq[0][1]), SIGCONT);

	} else if (strcmp(ligne->seq[0][0], "fg") == 0) {

		kill(atoi(ligne->seq[0][1]), SIGCONT);

		courant = atoi(ligne->seq[0][1]);

		sigprocmask(SIG_UNBLOCK, &ens_sig, NULL);

		waitpid(courant, &wstatus, 0);

		sigprocmask(SIG_BLOCK, &ens_sig, NULL);
	} else {

		courant = fork();

		if(courant < 0) {
			printf("Erreur lors du fork\n");
			exit(-1);
		} 

		if(ligne->backgrounded == NULL) {
			sigprocmask(SIG_UNBLOCK, &ens_sig, NULL);
		}

  		if(courant == 0) {

			//Redéfinir l'entrée standard si besoin
			if(ligne->in != NULL) {
				descin = open(ligne->in, O_RDONLY);

				if(descin < 0) {
					perror("Erreur lors de l'ouverture du fichier en entrée");
					exit(-1);
				}

				int err = dup2(descin, 0);
				if(err){
					printf("Erreur lors de la duplication du descripteur\n");
					exit(-1);
				}
				close(descin);
			} 

			//Redéfinir la sortie standard si besoin
			if(ligne->out != NULL) {
				printf("%s", ligne->out);
				descout = open(ligne->out, O_WRONLY | O_CREAT | O_TRUNC, 0660);

				if(descout < 0) {
					perror("Erreur lors de l'ouverture du fichier en sortie");
					exit(-1);
				}

				int err = dup2(descout, 1);
				if(err){
					printf("Erreur lors de la duplication du descripteur\n");
					exit(-1);
				}
				close(descout);
			}

			execvp(ligne->seq[0][0], ligne->seq[0]);
			
			perror("Erreur exec");
			exit(-1);

		} else {

			insertion(courant, ligne->seq, ligne->backgrounded);
			
			if (ligne->backgrounded == NULL) {

				pause();
			}
			courant = 0;
		}
	}
  } while(1);

  return EXIT_SUCCESS;
}
