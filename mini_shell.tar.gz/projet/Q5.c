#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdbool.h>
#include "readcmd.c"

/* Lire une commande et l'executer */
int main() {

  struct cmdline* ligne;

  int wstatus;

  do {

	//printf("%s ", getcwd(NULL, 0));
	printf(" ");

	ligne = readcmd();
	if(ligne->err != NULL){
		printf("Erreur lors de la lecture de la commande");
		exit(-1);
	}

	if (strcmp(ligne->seq[0][0], "cd") == 0) {

		chdir(ligne->seq[0][1]);
		printf("%s\n", getcwd(NULL, 0));

	} else if (strcmp(ligne->seq[0][0], "exit") == 0) {

		exit(EXIT_SUCCESS);

	} else {

		int courant = fork();

		if(courant < 0) {
			printf("Erreur lors du fork");
			exit(-1);
		} 

		if(courant == 0) {

			execvp(ligne->seq[0][0], ligne->seq[0]);

			perror("	erreur exec");
			exit(-1);

		} else {

			// On attend la fin du fils seulement s'il est au premier plan			
			if (ligne->backgrounded == NULL) { 
				wait(&wstatus);
			}
		}
	}
  } while(1);
}
