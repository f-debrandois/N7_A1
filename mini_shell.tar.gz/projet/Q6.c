#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdbool.h>
#include "readcmd.c"

#define TAILLE_MAX 30
#define NB_MAX 128

struct processus { //Structure permettant de garder toutes les données nécessaire à la commande jobs

  int pid; //pid du processus
  char* situation; //situation du processus : ACTIF ou SUSPENDU
  char commande[TAILLE_MAX]; //commande tapé pour lancer le processus

};

struct processus processus[NB_MAX]; //Tableau contenant la liste des processus non terminé
int nb_proc = 0; //Nombre de processus pas encore terminé


//Procedure permettant de rajouter un processus dans le tableau de processus
void insertion (int pid, char *** seq, char * fond) {
	processus[nb_proc].pid = pid;
	processus[nb_proc].situation = "ACTIF";

	// Ces deux boucles permettent de reformer la commande de départ
	int i = 0;
	while(seq[i] != NULL) {
		int j = 0;
		while(seq[i][j] != NULL) {
			if ((i == 0) & (j == 0)) {
				strcpy(processus[nb_proc].commande, seq[i][j]);
			} else {
				strcat(processus[nb_proc].commande, " ");
				strcat(processus[nb_proc].commande, seq[i][j]);
			}
			j++;
		}
		i++;
	}

	if (fond != NULL) {
		strcat(processus[nb_proc].commande, " &");
	}

	nb_proc++;
}


//Fonction renvoyant l'indice du processus dans le tableau de processus en fonction de son pid
int trouver_tab (int pid) {
  int x;

  for(int i = 0; i< nb_proc; i++) {
  	if (processus[i].pid == pid) {
  		x = i;
  		i = NB_MAX;
  	}
  }

  return x;
}


//Procedure permettant de retirer un processus dans le tableau de processus
void retirer_tab (int pid) {
  int x;

  for(int i = 0; i < nb_proc; i++) {
  	if (processus[i].pid == pid) {
  		x = i;
		if(x != (nb_proc-- - 1)) {
			processus[x] = processus[nb_proc];
		}
  		i = NB_MAX;
  	}
  }
}


//Procedure définissant le traitant pour le signal SIGCHLD
void suivi_fils (int sig) {

    int etat_fils, pid_fils;

    do {

        pid_fils = (int) waitpid(-1, &etat_fils, WNOHANG | WUNTRACED | WCONTINUED);

        if ((pid_fils == -1) && (errno != ECHILD)) {

            perror("waitpid");

            exit(EXIT_FAILURE);

        } else if (pid_fils > 0) {

            if (WIFSTOPPED(etat_fils)) {
		// Si le processus est suspendu on met à jour son état
		processus[trouver_tab(pid_fils)].situation = "SUSPENDU";

            } else if (WIFCONTINUED(etat_fils)) {
		// Si le processus est repris on met à jour son état
		processus[trouver_tab(pid_fils)].situation = "ACTIF";

            } else if (WIFEXITED(etat_fils)) {
		// Si le processus est terminé on le retire du tableau
		retirer_tab (pid_fils);

            } else if (WIFSIGNALED(etat_fils)) {
		// Si le processus est terminé on le retire du tableau
		retirer_tab (pid_fils);

            }

        }

    } while (pid_fils > 0);
}




/* Lire une commande et l'executer */
int main() {

  //Associer le traitant suivi_fils au signal SIGCHLD
  signal(SIGCHLD, suivi_fils);

  struct cmdline* ligne;

  int wstatus;

  do {

	//printf("%s ", getcwd(NULL, 0));
	printf(" ");

	ligne = readcmd();
	if(ligne->err != NULL){
		printf("Erreur lors de la lecture de la commande");
		exit(-1);
	}

	if (strcmp(ligne->seq[0][0], "cd") == 0) {

		chdir(ligne->seq[0][1]);
		printf("%s \n", getcwd(NULL, 0));

	} else if (strcmp(ligne->seq[0][0], "exit") == 0) {

		exit(EXIT_SUCCESS);

	} else if (strcmp(ligne->seq[0][0], "jobs") == 0) {
		//Afficher tous les processus du tableau
		for(int i = 0; i < nb_proc; i++) {
			printf("[%d]    %d    %s    ", i+1, processus[i].pid, processus[i].situation);
			printf("%s \n", processus[i].commande);
		}

	} else if (strcmp(ligne->seq[0][0], "stop") == 0) {
		//Suspendre le processus en fonction de son pid
		kill(atoi(ligne->seq[0][1]), SIGSTOP);

	} else if (strcmp(ligne->seq[0][0], "bg") == 0) {
		//Reprendre le processus en fonction de son pid
		kill(atoi(ligne->seq[0][1]), SIGCONT);

	} else if (strcmp(ligne->seq[0][0], "fg") == 0) {
		//Reprendre le processus en fonction de son pid
		kill(atoi(ligne->seq[0][1]), SIGCONT);
		//Attendre sa fin car il est au premier plan
		waitpid(atoi(ligne->seq[0][1]), &wstatus, 0);

	} else {

		int courant = fork();

		if(courant < 0) {
			printf("Erreur lors du fork");
			exit(-1);
		} 

		if(courant == 0) {

			execvp(ligne->seq[0][0], ligne->seq[0]);

			perror("Erreur exec");
			exit(-1);

		} else {

			insertion(courant, ligne->seq, ligne->backgrounded);
			
			if (ligne->backgrounded == NULL) {
				/*Attendre de recevoir un signal avant de continuer.
				 *Le signal attendu est SIGCHLD, mais d'autres signaux
				 *peuvent intervenir comme SIGSTOP ou SIGKILL.
				*/
				pause();
			} 
		}
	}
  } while(1);

  return EXIT_SUCCESS;
}
