#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdbool.h>
#include "readcmd.c"


/* Lire une commande et l'executer */
int main() {

  struct cmdline* ligne;

  do {

	printf(" ");

	ligne = readcmd();
	if(ligne->err != NULL){
		printf("Erreur lors de la lecture de la commande");
		exit(-1);
	}

	int courant = fork();

	if(courant < 0) {
		printf("Erreur lors du fork");
		exit(-1);
	} 

	if(courant == 0) {

		execvp(ligne->seq[0][0], ligne->seq[0]);

		perror("	erreur exec");
		exit(-1);

	}

  } while(1);
}
