#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>
#include "readcmd.c"

#define TAILLE_MAX 30
#define NB_MAX 128

struct processus {

  int pid;
  char* situation;
  char commande[TAILLE_MAX];

};

struct processus processus[NB_MAX];
int nb_proc = 0;


void insertion (int pid, char *** seq, char * fond) {
	processus[nb_proc].pid = pid;
	processus[nb_proc].situation = "ACTIF";

	int i = 0;
	while(seq[i] != NULL) {
		int j = 0;
		while(seq[i][j] != NULL) {
			if ((i == 0) & (j == 0)) {
				strcpy(processus[nb_proc].commande, seq[i][j]);
			} else {
				strcat(processus[nb_proc].commande, " ");
				strcat(processus[nb_proc].commande, seq[i][j]);
			}
			j++;
		}
		i++;
	}

	if (fond != NULL) {
		strcat(processus[nb_proc].commande, " &");
	}

	nb_proc++;
}


int trouver_tab (int pid) {
  int x;

  for(int i = 0; i< nb_proc; i++) {
  	if (processus[i].pid == pid) {
  		x = i;
  		i = NB_MAX;
  	}
  }

  return x;
}


void retirer_tab (int pid) {
  int x;

  for(int i = 0; i < nb_proc; i++) {
  	if (processus[i].pid == pid) {
  		x = i;
		if(x != (nb_proc-- - 1)) {
			processus[x] = processus[nb_proc];
		}
  		i = NB_MAX;
  	}
  }
}


//Procedure permettant de mettre à jour l'entrée et la sortie par défault
//Le travail ajouter à la question précédante est mis dans cette fonction 
void E_S (struct cmdline *l) {
  if(l->in != NULL) {
  	int descin = open(l->in, O_RDONLY);

  	if(descin < 0) {
		perror("Erreur lors de l'ouverture du fichier en entrée");
  		exit(3);
	  }

  	int err = dup2(descin, 0);
  	if(err < 0){
		printf("Erreur lors de la duplication du descripteur\n");
		exit(4);
	}
	close(descin);
  } 

  if(l->out != NULL) {
	int descout = open(l->out, O_WRONLY | O_CREAT | O_TRUNC, 0660);

	if(descout < 0) {
		perror("Erreur lors de l'ouverture du fichier en sortie");
		exit(5);
	}

	int err = dup2(descout, 1);
	if(err < 0){
		printf("Erreur lors de la duplication du descripteur\n");
		exit(6);
	}
	close(descout);
  }
}
 

void suivi_fils (int sig) {

    int etat_fils, pid_fils;

    do {

        pid_fils = (int) waitpid(-1, &etat_fils, WNOHANG | WUNTRACED | WCONTINUED);

        if ((pid_fils == -1) && (errno != ECHILD)) {

            perror("waitpid");

            exit(EXIT_FAILURE);

        } else if (pid_fils > 0) {

            if (WIFSTOPPED(etat_fils)) {

		processus[trouver_tab(pid_fils)].situation = "SUSPENDU";

            } else if (WIFCONTINUED(etat_fils)) {

		processus[trouver_tab(pid_fils)].situation = "ACTIF";

            } else if (WIFEXITED(etat_fils)) {

		retirer_tab (pid_fils);

            } else if (WIFSIGNALED(etat_fils)) {

		retirer_tab (pid_fils);

            }

        }

    } while (pid_fils > 0);

    /* autres actions après le suivi des changements d'état */

}


int courant = 0;


void ctrl_c (int sig) {
  kill(courant, SIGKILL);
  printf("\n");
}


void ctrl_z (int sig) {
  kill(courant, SIGSTOP);
  printf("\n");
}



/* Lire une commande et l'executer */
int main() {

  sigset_t ens_sig;

  sigemptyset(&ens_sig);
  sigaddset(&ens_sig, SIGINT);
  sigaddset(&ens_sig, SIGTSTP);

  signal(SIGCHLD, suivi_fils);
  signal(SIGINT, ctrl_c);
  signal(SIGTSTP, ctrl_z);

  struct cmdline* ligne;

  int wstatus;

  do {

	sigprocmask(SIG_BLOCK, &ens_sig, NULL);
	//printf("%s ", getcwd(NULL, 0));
	printf(" ");

	ligne = readcmd();
	if(ligne->err != NULL){
		printf("Erreur lors de la lecture de la commande\n");
		exit(-1);
	}

	if (strcmp(ligne->seq[0][0], "cd") == 0) {

		chdir(ligne->seq[0][1]);
		printf("%s \n", getcwd(NULL, 0));

	} else if (strcmp(ligne->seq[0][0], "exit") == 0) {

		exit(EXIT_SUCCESS);

	} else if (strcmp(ligne->seq[0][0], "jobs") == 0) {

		for(int i = 0; i < nb_proc; i++) {
			printf("[%d]    %d    %s    ", i+1, processus[i].pid, processus[i].situation);
			printf("%s \n", processus[i].commande);
		}

	} else if (strcmp(ligne->seq[0][0], "stop") == 0) {

		kill(atoi(ligne->seq[0][1]), SIGSTOP);

	} else if (strcmp(ligne->seq[0][0], "bg") == 0) {

		kill(atoi(ligne->seq[0][1]), SIGCONT);

	} else if (strcmp(ligne->seq[0][0], "fg") == 0) {

		kill(atoi(ligne->seq[0][1]), SIGCONT);

		courant = atoi(ligne->seq[0][1]);

		sigprocmask(SIG_UNBLOCK, &ens_sig, NULL);

		waitpid(courant, &wstatus, 0);

		sigprocmask(SIG_BLOCK, &ens_sig, NULL);
	} else {

		courant = fork();

		if(courant < 0) {
			printf("Erreur lors du fork\n");
			exit(-1);
		} 

		if(ligne->backgrounded == NULL) {
			sigprocmask(SIG_UNBLOCK, &ens_sig, NULL);
		}

  		if(courant == 0) {

			//Différencier le cas d'une commande sans tube d'une commande nécessitant un tube
			if(ligne->seq[1] != NULL) { //Commande nécessitant un tube
				int p[2];
				int retour;

				retour = pipe(p);
				if(retour < -1) {
					printf("Erreur pipe\n");
					exit(-1);
				}

				retour = fork();

				if(retour < 0) {
					printf("Erreur lors du fork\n");
					exit(-1);
				} 

				if(retour == 0) { //Première commande à réaliser
					close(p[0]);

					//Affecter l'entrée et la sortie standard si nécessaire
					E_S(ligne);

					//Réaffecter la sortie standard à l'entrée du tube
					retour = dup2(p[1], 1);
					if(retour < 0){
						printf("Erreur lors de la duplication du descripteur\n");
						exit(-1);
					}

					execvp(ligne->seq[0][0], ligne->seq[0]);

					perror("Erreur exec");
					exit(-1);
				} else { //Deuxième commande à réaliser nécessitant la première commande
					close(p[1]);

					//Affecter l'entrée et la sortie standard si nécessaire
					E_S(ligne);

					//Réaffecter l'entrée standard à la sortie du tube
					retour = dup2(p[0], 0);
					if(retour < 0){
						printf("Erreur lors de la duplication du descripteur\n");
						exit(-1);
					}

					execvp(ligne->seq[1][0], ligne->seq[1]);

					perror("Erreur exec");
					exit(-1);
				}

			} else { //Commande ne nécessitant pas d'un tube
				E_S(ligne);

				execvp(ligne->seq[0][0], ligne->seq[0]);
			
				perror("Erreur exec");
				exit(-1);
			}

		} else {

			insertion(courant, ligne->seq, ligne->backgrounded);
			
			if (ligne->backgrounded == NULL) {

				pause();
			}
			courant = 0;
		}
	}
  } while(1);

  return EXIT_SUCCESS;
}
